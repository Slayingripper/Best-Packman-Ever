import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import sample.Main;

import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Window.Type;
import java.awt.Toolkit;

public class menu {

	private JFrame frmPacMan;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu window = new menu();
					window.frmPacMan.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPacMan = new JFrame();
		frmPacMan.setIconImage(Toolkit.getDefaultToolkit().getImage(menu.class.getResource("/sample/pacman.png")));
		frmPacMan.setType(Type.UTILITY);
		frmPacMan.setTitle("PAC MAN");
		frmPacMan.setBounds(100, 100, 580, 476);
		frmPacMan.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPacMan.getContentPane().setLayout(null);
		JButton Playbtn = new JButton("Play");
		Playbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				launch(main);
				
			}
		});
		Playbtn.setBounds(73, 331, 89, 23);
		frmPacMan.getContentPane().add(Playbtn);
		
		JButton Setupbtn = new JButton("Setup");
		Setupbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Setupbtn.setBounds(419, 331, 89, 23);
		frmPacMan.getContentPane().add(Setupbtn);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Admin\\Desktop\\best-packman-ever-master\\bin\\sample\\Pac_man.png"));
		lblNewLabel.setBounds(96, 24, 343, 296);
		frmPacMan.getContentPane().add(lblNewLabel);
	}
}
